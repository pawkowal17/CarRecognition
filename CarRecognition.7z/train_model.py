from CNN import Recognition

network = Recognition()
network.train_net()
